import fs from 'node:fs';
import {publicRects,publicStairs} from '../dist/public-layout.js';
import {floorHeight} from '../dist/physics.js';
import {stands} from '../dist/stadium-layout.js';
const C={ink:'#223c51',muted:'#526c7b',floor:'#dce5e8',navy:'#394e73',turq:'#129da7',white:'#fbfcfa',gold:'#b16e20'};
const text=(x,y,t,size=17,color=C.ink)=>`<text x="${x}" y="${y}" font-size="${size}" fill="${color}">${t}</text>`;
const line=(pts,color=C.ink,width=2,dash='')=>`<polyline points="${pts.map(p=>p.join(',')).join(' ')}" fill="none" stroke="${color}" stroke-width="${width}" stroke-dasharray="${dash}"/>`;
const start=(title,sub)=>`<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="930" viewBox="0 0 1400 930"><rect width="1400" height="930" fill="#f4f7f8"/><g font-family="Arial,sans-serif" fill="${C.ink}">${text(40,43,title,28)}${text(40,75,sub,17,C.muted)}`;
const foot=text(40,897,'Modelo académico con dimensiones propuestas · v15 · Diagrama del modelo, no relevamiento ni captura 3D.',15)+'</g></svg>';
const save=(name,s)=>fs.writeFileSync(new URL('../dist/'+name,import.meta.url),s+foot);
let svg=start('Principal · planta de circulaciones','Planta desarrollada: conserva distancias locales; la curvatura se aplica en el modelo. Izquierda = entrando hacia la cancha.');
const X=u=>700-u*10.8,Y=d=>130+d*16;
const rect=(u0,u1,d0,d1,fill)=>`<rect x="${X(u1)}" y="${Y(d0)}" width="${(u1-u0)*10.8}" height="${(d1-d0)*16}" fill="${fill}" stroke="${C.muted}"/>`;
svg+=rect(-57.5,57.5,2,8.5,'#d3dde8')+rect(-57.5,57.5,14,20,'#d3dde8')+rect(-57.5,57.5,22,30.5,'#d3dde8')+rect(-51,51,12.5,14,'#aabbcc');
for(const r of publicRects)svg+=rect(r.u0,r.u1,r.d0,r.d1,C.floor);
svg+=rect(.08,2.7,17,23,'#80cece')+rect(-2.7,-.08,17,18.76,'#99aab9');
for(let i=0;i<=4;i++)svg+=line([[X(-2.7),Y(17+i*.44)],[X(-.08),Y(17+i*.44)]],C.ink,1);
for(const s of publicStairs){const a=Math.min(s.foot,s.end),b=Math.max(s.foot,s.end);svg+=rect(a,b,10.2,12.5,'#9aacbf');for(let i=0;i<=20;i++){const u=s.foot+s.dir*i*.3;svg+=line([[X(u),Y(10.2)],[X(u),Y(12.5)]],C.ink,1);}svg+=line([[X(s.foot),Y(10.1)],[X(s.end),Y(10.1)],[X(s.end),Y(12.5)]],C.turq,3);const mid=s.top+s.dir;svg+=line([[X(s.foot-s.dir),Y(11.35)],[X(mid),Y(11.35)],[X(mid),Y(13.35)],[X(mid+s.dir*3),Y(13.35)]],C.gold,3);}
svg+=line([[X(2.7),Y(33)],[X(-2.7),Y(33)]],C.turq,6);
svg+=text(570,118,'CAMPO · visual frontal',18)+text(165,205,'Gradas inferiores',16)+text(1040,402,'Gradas intermedias',16)+text(1030,565,'Gradas superiores',16);
svg+=text(210,710,'Izquierda al entrar',16)+text(1010,710,'Derecha al entrar',16)+text(554,710,'EXPLANADA / PORTONES',17);
svg+=text(450,657,'Vestíbulo ±0,00',15)+line([[592,651],[669,Y(29)]],C.muted,1)+text(815,648,'Puerta derecha: uso sin confirmar',15)+line([[810,641],[X(-3.5),Y(29.2)]],C.muted,1);
svg+=text(335,563,'Ramificaciones previas',16)+line([[526,558],[X(5),Y(25)]],C.muted,1)+text(805,501,'Rampa izquierda / escalera corta derecha',15)+line([[799,496],[X(0),Y(20)]],C.muted,1);
svg+=text(805,459,'Conectores: +0,00 → +0,72',15)+line([[800,455],[X(-6.6),Y(18)]],C.muted,1)+text(165,260,'PASILLO BAJO +0,72 · 4,00 m entre caras',16);
svg+=text(156,365,'Paso contiguo 1,50 m',15)+line([[340,359],[X(16),Y(9.2)]],C.muted,1)+text(944,368,'Subida → descanso → giro',15)+line([[934,363],[X(-15),Y(12.9)]],C.muted,1);
svg+=line([[X(-51),Y(11.35)],[X(51),Y(11.35)]],C.gold,1.5,'6 5')+text(100,Y(11.35)+6,'B',18)+text(1270,Y(11.35)+6,'B',18);
svg+=line([[X(6.6),Y(1)],[X(6.6),Y(33)]],C.gold,1.5,'6 5')+text(X(6.6)+8,Y(1)+7,'A',18)+text(X(6.6)+8,Y(33)-6,'A',18);
svg+=text(40,753,'Observado: paso entre gradas, escaleras longitudinales, pasos contiguos, descansos protegidos y tramos abiertos.',16)+text(40,784,'Descripción del usuario: puerta derecha, bifurcación previa y continuidad hacia baños todavía sin relevar.',16)+text(40,815,'Propuesto: posiciones de ascensos, cotas y conexiones. No se afirma simetría ni se duplican escaleras por cada foto.',16)+text(40,846,'Tramos hasta u = ±51 m: reserva ajustable; los extremos y los baños no se presentan como terminados.',16);
save('entrada-planta.svg',svg);

svg=start('Principal · corte transversal A–A','Sección en u = +6,60 m: conector lateral bajo las gradas → pasillo bajo → sectores inferiores hacia el campo.');
const A=d=>110+(34-d)*32,B=h=>635-h*29;
const ln=(pts,col=C.ink,w=3,dash='')=>line(pts.map(([d,h])=>[A(d),B(h)]),col,w,dash);
const box=(d0,d1,h0,h1,fill)=>`<rect x="${A(d1)}" y="${B(h1)}" width="${(d1-d0)*32}" height="${(h1-h0)*29}" fill="${fill}" stroke="${C.muted}"/>`;
for(const h of[0,.72,4.2,7.98,12.18,-3.6,-4.8])svg+=ln([[34,h],[-1,h]],'#d0dbe0',1,'4 6')+text(30,B(h)+5,h.toFixed(2),13);
svg+=box(23.6,26.6,-.18,0,C.floor)+ln([[23.6,0],[12.5,.72]],C.turq,5)+box(8.5,12.5,.50,.72,C.floor);
for(const[da,db]of[[2,8.5],[14,20],[22,30.5]]){const step=da===14?1/3:.425;for(let d=da;d<db-1e-5;d+=step){const e=Math.min(d+step,db),h=floorHeight(stands[0],e);svg+=box(d,e,h-.20,h,'#879aaf');}}
for(const[d0,d1,h]of[[0,2,0],[12.5,14,4.2],[20,22,7.98],[30.5,32.5,12.18]])svg+=box(d0,d1,h-.2,h,'#879aaf');
svg+=box(8.26,8.5,.50,3.95,C.white)+box(8.20,8.55,3.95,4.06,C.navy)+box(12.5,12.76,3.67,5.15,C.navy)+box(12.46,12.81,5.15,5.25,C.navy);
const roof=d=>15.98+.9*(d-4)/29.5+.22*Math.sin(Math.PI*(d-4)/29.5);
svg+=ln([[4,roof(4)],[8.3,roof(8.3)]],C.navy,6)+ln([[12.8,roof(12.8)],[33.5,roof(33.5)]],C.navy,6)+ln([[8.3,14.9],[12.8,14.9]],C.turq,2,'4 4');
svg+=text(A(13.4),230,'Vacío sobre el pasillo',16)+text(A(13.4),252,'Cubierta conservada a ambos lados',14)+text(140,229,'Tres niveles conservados',19)+text(140,255,'+4,20 / +7,98 / +12,18 m',16);
svg+=text(150,508,'Conector propuesto',17)+text(150,532,'11,10 m / 6,49 % / +0,72 m',15)+line([[394,527],[A(18),B(.36)]],C.muted,1)+text(1080,448,'Gradas inferiores',16)+text(910,684,'Pasillo +0,72',17)+text(909,708,'Abertura bajo dintel: 2,95 m',15)+line([[939,675],[A(10.5),B(.72)]],C.muted,1);
svg+=ln([[28.25,-3.6],[14.8,-3.6]],'#876994',4)+ln([[10.38,-4.8],[0,-4.8]],'#876994',4)+text(170,782,'Vestuarios −3,60 y túnel −4,80: cotas conservadas, proyectadas en este corte.',15,'#70527e');
svg+=text(40,829,'La sección pasa por un conector, no por el portón. El vestíbulo axial conserva rampa de 6,00 m y cuatro escalones.',16)+text(40,855,'Cotas propuestas del modelo. Las rampas no se declaran accesibles ni homologadas.',16);
save('entrada-corte.svg',svg);

svg=start('Principal · corte longitudinal B–B','Pasillo desarrollado en d = 11,35 m. Las escaleras suben a lo largo de la tribuna y salen hacia atrás por los descansos.');
const U=u=>710-u*10.8,H=h=>510-h*49;
const l=(pts,col=C.ink,w=3,dash='')=>line(pts.map(([u,h])=>[U(u),H(h)]),col,w,dash);
for(const h of[.72,4.2,5.25])svg+=l([[-51,h],[51,h]],'#b5c3ce',1,'4 5')+text(53,H(h)+5,'+'+h.toFixed(2),14);
svg+=l([[-51,.72],[51,.72]],C.turq,5);
for(const s of publicStairs){let pts=[[s.foot,.72]];for(let i=0;i<20;i++){const u=s.foot+s.dir*i*.3,h=.72+(i+1)*.174;pts.push([u,h],[u+s.dir*.3,h]);}pts.push([s.end,4.2]);svg+=l(pts,C.navy,4)+l([[s.foot,1.75],[s.top,5.23],[s.end,5.23]],C.turq,3)+l([[s.end,4.2],[s.end,5.23]],C.turq,4);const mid=s.top+s.dir;svg+=`<circle cx="${U(mid)}" cy="${H(4.2)-12}" r="7" fill="${C.gold}"/>`;svg+=text(U(s.dir>0?s.end+13:s.end-1),196,'Descanso +4,20 / salida lateral',15)+line([[U(mid),203],[U(mid),H(4.2)-21]],C.muted,1);}
svg+=text(160,400,'Continuación preparada',16)+text(160,424,'sin interiores inventados',15)+text(1000,400,'Continuación preparada',16)+text(1000,424,'hacia el extremo',15)+text(186,559,'Piso del paso contiguo: continuo a +0,72; queda fuera del plano de corte.',17);
svg+=text(120,614,'Escaleras propuestas: 20 contrahuellas × 0,174 m; 6,00 m de desarrollo; ancho 2,30 m; descanso de 2,00 m.',16)+text(120,646,'Paso contiguo: 1,50 m entre muros y zanca. La protección del fondo del descanso deja libre el giro de salida.',16)+text(120,694,'La geometría comparte cotas con pisos y colisiones. Los extremos exactos y las puertas de baños siguen pendientes.',16)+text(120,739,'Observado: escalera, paso contiguo, coronaciones, ventanillas y baranda de descanso.',16)+text(120,771,'Propuesto: ubicación longitudinal de los dos ascensos y su adaptación a las galerías de la ampliación.',16)+text(120,812,'Los puntos dorados indican giros fuera del corte hacia la galería superior; el frente protege el vacío.',16);
save('pasillo-corte-longitudinal.svg',svg);
